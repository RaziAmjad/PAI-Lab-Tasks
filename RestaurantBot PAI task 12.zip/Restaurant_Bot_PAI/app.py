from flask import Flask, render_template, request, jsonify
from retriever import fetch_response

application = Flask(__name__)

@application.route('/')
def index():
    return render_template('index.html')

@application.route('/query', methods=['POST'])
def query():
    payload = request.get_json()
    user_input = payload.get('question', '').strip()
    
    if not user_input:
        return jsonify({"error": "Please type a question before submitting."})
    
    response = fetch_response(user_input)
    
    if isinstance(response, str):
        return jsonify({"answer": response, "matched_question": "", "confidence": 0})
    
    return jsonify(response)

if __name__ == '__main__':
    application.run(debug=True)
