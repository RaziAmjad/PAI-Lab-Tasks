from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from knowledge_base import knowledge_base

# Initialize the sentence embedding model
embedding_model = SentenceTransformer('all-MiniLM-L6-v2')

# Separate questions and answers from the knowledge base
all_questions = [entry["question"] for entry in knowledge_base]
all_answers = [entry["answer"] for entry in knowledge_base]

# Generate vector embeddings for all questions
question_embeddings = embedding_model.encode(all_questions)
question_embeddings = np.array(question_embeddings).astype('float32')

# Set up FAISS index for similarity-based retrieval
vector_dimension = question_embeddings.shape[1]
faiss_index = faiss.IndexFlatL2(vector_dimension)
faiss_index.add(question_embeddings)

def fetch_response(user_query):
    # Embed the incoming user query
    query_vector = embedding_model.encode([user_query])
    query_vector = np.array(query_vector).astype('float32')
    
    # Retrieve the closest matching question from the index
    distances, indices = faiss_index.search(query_vector, 1)
    
    top_index = indices[0][0]
    top_distance = distances[0][0]
    
    # Reject queries that are too far from any known question
    if top_distance > 2.0:
        return "I'm sorry, I don't have an answer for that. Please ask something related to restaurants or the dining experience."
    
    best_match_question = all_questions[top_index]
    best_match_answer = all_answers[top_index]
    
    return {
        "matched_question": best_match_question,
        "answer": best_match_answer,
        "confidence": round(float(1 / (1 + top_distance)) * 100, 2)
    }
