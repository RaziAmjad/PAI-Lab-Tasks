knowledge_base = [
    {
        "question": "What exactly is a restaurant?",
        "answer": "A restaurant is an establishment where customers visit to have meals cooked and served by the staff on duty. It offers a variety of food and beverage options through a menu, and customers pay for what they order."
    },
    {
        "question": "How can I book a table at a restaurant?",
        "answer": "To book a table, you can call the restaurant directly, visit their official website, or use online platforms such as OpenTable or Resy. You will need to share your name, preferred date and time, and the number of guests joining you."
    },
    {
        "question": "How is fine dining different from casual dining?",
        "answer": "Fine dining provides an upscale environment with gourmet cuisine, attentive professional service, and premium pricing. Casual dining, on the other hand, is laid-back, budget-friendly, and suitable for families with a more varied menu selection."
    },
    {
        "question": "What steps should I take if I have a food allergy?",
        "answer": "Make sure to notify your waiter about your allergy before placing an order. Ask about the dish ingredients and food preparation methods. Most restaurants are equipped to handle common allergies such as peanuts, gluten intolerance, or dairy sensitivity."
    },
    {
        "question": "What is the right amount to tip at a restaurant?",
        "answer": "A standard tip ranges from 15% to 20% of the total bill for satisfactory service. In the United States, 18 to 20 percent is the general expectation. While tipping customs differ by country, it is almost always a welcome gesture."
    },
    {
        "question": "Can you explain what a prix fixe menu is?",
        "answer": "A prix fixe menu is a pre-set multi-course meal sold at a flat price. For instance, it might include an appetizer, a main dish, and a dessert, all bundled together for one combined cost rather than being priced individually."
    },
    {
        "question": "What is meant by the term farm-to-table?",
        "answer": "Farm-to-table refers to the practice of a restaurant obtaining its ingredients directly from local farms or producers. This approach ensures greater freshness, benefits local agriculture, and helps lower the environmental impact associated with food transportation."
    },
    {
        "question": "Is it possible to request changes to a dish at a restaurant?",
        "answer": "Yes, the majority of restaurants are happy to make adjustments to menu items upon request. Feel free to ask for ingredients to be left out or added, a different cooking method, or a change in spice intensity. Just let your server know your preferences politely."
    },
    {
        "question": "What is a tasting menu and how does it work?",
        "answer": "A tasting menu is a curated sequence of small dishes personally selected by the head chef to highlight the restaurant's finest or most seasonal creations. It typically spans many courses and is a hallmark feature of upscale fine dining establishments."
    },
    {
        "question": "What sets a bistro apart from a brasserie?",
        "answer": "A bistro is an intimate, informal eatery that serves simple home-cooked style food at reasonable prices. A brasserie is a larger, more lively venue that operates throughout the day and typically offers heartier meals accompanied by beer and wine selections."
    },
    {
        "question": "Who is a sommelier and what do they do?",
        "answer": "A sommelier is a certified wine specialist employed at a restaurant. Their role is to assist diners in selecting wines that complement their meal choices and to oversee and maintain the restaurant's wine inventory."
    },
    {
        "question": "What does the cooking term al dente mean?",
        "answer": "Al dente is an Italian culinary phrase that describes pasta or vegetables cooked just enough to retain a slight firmness when bitten, without being overly soft or mushy. It is widely regarded as the gold standard for preparing pasta correctly."
    },
    {
        "question": "What is a table d'hote menu?",
        "answer": "A table d'hote menu provides a complete multi-course meal at a single fixed rate with a limited selection of choices. Unlike an a la carte menu where individual items are priced separately, table d'hote bundles everything into one inclusive price."
    },
    {
        "question": "How should I handle bad food or service at a restaurant?",
        "answer": "Calmly bring the issue to your server's attention or request to speak with the restaurant manager. Describe your concern clearly and respectfully. Restaurants will often offer to replace the dish or apply a discount. You may also share feedback through an online review platform afterward."
    },
    {
        "question": "What does BYOB mean in the context of a restaurant?",
        "answer": "BYOB is short for Bring Your Own Bottle, indicating that the restaurant permits guests to bring their own alcoholic beverages. A corkage fee is often charged by the restaurant to cover the cost of serving and presenting your bottle."
    }
]
