from flask import Flask, render_template, request, jsonify
import random
import re

app = Flask(__name__)

# ── Restaurant Information ────────────────────────────────────────
RESTAURANT_INFO = {
    "name": "Casa di Roma",
    "tagline": "Traditional Italian Flavors Since 2001",
    "address": "17 Olive Lane, Midtown, New York, NY 10036",
    "phone": "+1 (212) 555-0274",
    "email": "hello@casadiroma.com",
    "website": "www.casadiroma.com",
    "hours": {
        "monday":    "12:00 PM – 10:00 PM",
        "tuesday":   "12:00 PM – 10:00 PM",
        "wednesday": "12:00 PM – 10:00 PM",
        "thursday":  "12:00 PM – 10:00 PM",
        "friday":    "12:00 PM – 11:30 PM",
        "saturday":  "10:30 AM – 11:30 PM",
        "sunday":    "10:30 AM – 9:30 PM",
    },
    "menu": {
        "Appetizers": [
            {"name": "Crostini al Pomodoro",      "price": "$11", "desc": "Toasted bread topped with vine tomatoes, fresh basil, and cold-pressed olive oil",    "veg": True},
            {"name": "Mozzarella e Salame",        "price": "$17", "desc": "Fresh mozzarella slices with Italian salami and rocket leaves"},
            {"name": "Minestra del Giorno",        "price": "$9",  "desc": "Chef's seasonal soup served alongside warm focaccia bread",                           "veg": True},
            {"name": "Anelli di Calamaro",         "price": "$15", "desc": "Golden-fried squid rings accompanied by homemade tomato dipping sauce"},
        ],
        "Pasta": [
            {"name": "Spaghetti alla Gricia",      "price": "$21", "desc": "Roman-style pasta with cured pork cheek, black pepper, and aged Pecorino"},
            {"name": "Tagliatelle al Ragù Lento",  "price": "$25", "desc": "Hand-rolled tagliatelle with a slow-cooked beef and tomato ragù"},
            {"name": "Rigatoni alla Siciliana",    "price": "$19", "desc": "Roasted aubergine, crushed tomato, basil, and salted ricotta",                       "veg": True},
            {"name": "Fettuccine al Tartufo",      "price": "$31", "desc": "Silky fettuccine with black truffle, aged butter, and Parmigiano shavings",          "veg": True},
        ],
        "Main Courses": [
            {"name": "Orata al Cartoccio",         "price": "$36", "desc": "Sea bream baked in parchment with cherry tomatoes, olives, and fresh herbs"},
            {"name": "Costata alla Fiorentina",    "price": "$62", "desc": "Premium dry-aged rib-eye steak, prepared Florentine-style (price per person)"},
            {"name": "Pollo alla Romana",          "price": "$28", "desc": "Roman-style braised chicken with peppers, white wine, and garden herbs"},
            {"name": "Parmigiana di Melanzane",    "price": "$23", "desc": "Layered eggplant baked with house tomato sauce and melted cheese",                   "veg": True},
        ],
        "Desserts": [
            {"name": "Tiramisù Artigianale",       "price": "$11", "desc": "Artisan tiramisù layered with mascarpone cream and espresso-soaked ladyfingers",     "veg": True},
            {"name": "Budino di Vaniglia",         "price": "$9",  "desc": "Silky vanilla custard finished with a seasonal fruit compote",                       "veg": True},
            {"name": "Gelato della Casa",          "price": "$8",  "desc": "Two scoops of house-churned gelato — ask your server for today's selection",         "veg": True},
            {"name": "Cannoli di Palermo",         "price": "$10", "desc": "Crisp pastry tubes filled with sweet ricotta cream and crushed hazelnuts",            "veg": True},
        ],
        "Beverages": [
            {"name": "Vino della Casa (glass)",    "price": "$11", "desc": "Rotating Italian red or white, selected by our sommelier"},
            {"name": "Acqua Frizzante",            "price": "$4",  "desc": "Italian sparkling mineral water 500ml"},
            {"name": "Caffè Doppio",               "price": "$4",  "desc": "Double-shot Italian espresso"},
            {"name": "Spritz Veneziano",           "price": "$13", "desc": "A refreshing Italian aperitivo with Aperol and prosecco"},
        ],
    },
    "features": [
        "Al fresco terrace seating (spring & summer)",
        "Dedicated private dining room for up to 18 guests",
        "Curated Italian wine list and handcrafted cocktails",
        "Gluten-free pasta available upon request (+$3)",
        "Plant-based menu available",
        "Step-free access throughout the restaurant",
        "Complimentary parking on weeknights from 6 PM",
        "Live acoustic music every Friday & Saturday 8–10 PM",
    ],
    "reservation": {
        "phone":  "+1 (212) 555-0274",
        "online": "www.casadiroma.com/book",
        "note":   "Advance booking is advised on weekends. Walk-in guests are welcome subject to table availability.",
    }
}

# ── Intent Recognition ────────────────────────────────────────────

def identify_intent(msg):
    msg = msg.lower()
    if any(w in msg for w in ["hour", "open", "close", "time", "when", "schedule", "timing"]):
        return "hours"
    if any(w in msg for w in ["menu", "food", "eat", "dish", "meal", "item", "price", "cost", "how much",
                               "appetizer", "starter", "pasta", "main", "dessert", "drink", "beverage"]):
        return "menu"
    if any(w in msg for w in ["veg", "vegetarian", "no meat", "plant"]):
        return "vegetarian"
    if any(w in msg for w in ["address", "location", "where", "direction", "find"]):
        return "location"
    if any(w in msg for w in ["reserv", "book", "table", "seat"]):
        return "reservation"
    if any(w in msg for w in ["phone", "call", "contact", "email", "reach"]):
        return "contact"
    if any(w in msg for w in ["park", "parking"]):
        return "parking"
    if any(w in msg for w in ["private", "event", "party", "group", "function"]):
        return "events"
    if any(w in msg for w in ["music", "live", "entertainment"]):
        return "music"
    if any(w in msg for w in ["special", "feature", "facility", "amenity", "outdoor", "vegan", "gluten"]):
        return "features"
    if any(w in msg for w in ["hello", "hi", "hey", "howdy", "good morning", "good evening", "greet"]):
        return "greeting"
    if any(w in msg for w in ["help", "what can", "what do", "assist"]):
        return "help"
    if any(w in msg for w in ["recommend", "suggest", "popular", "best", "favourite", "favorite", "must try"]):
        return "recommend"
    return "unknown"


def generate_reply(intent, msg):
    r = RESTAURANT_INFO

    if intent == "greeting":
        return (f"Benvenuto a <strong>{r['name']}</strong> — {r['tagline']}! 🍕<br><br>"
                "I'm your digital host. Feel free to ask me about our menu, opening times, reservations, or how to find us. "
                "How may I assist you today?")

    if intent == "help":
        return ("Here's what I'm able to help you with:<br><br>"
                "🕐 <strong>Opening times</strong> — Ask \"When do you open?\"<br>"
                "🍽️ <strong>Menu & pricing</strong> — Ask \"What's on the menu?\" or \"What pasta dishes do you serve?\"<br>"
                "📍 <strong>Our location</strong> — Ask \"Where are you based?\"<br>"
                "📞 <strong>Get in touch</strong> — Ask \"How can I contact you?\"<br>"
                "📅 <strong>Table booking</strong> — Ask \"How do I reserve a table?\"<br>"
                "🥗 <strong>Vegetarian choices</strong> — Ask \"What's suitable for vegetarians?\"<br>"
                "⭐ <strong>Chef's picks</strong> — Ask \"What would you recommend?\"")

    if intent == "hours":
        hours_html = "".join(
            f"<tr><td><strong>{day.capitalize()}</strong></td><td>{time}</td></tr>"
            for day, time in r["hours"].items()
        )
        return (f"Our opening times are as follows:<br><br>"
                f"<table class='info-table'>{hours_html}</table>")

    if intent == "location":
        return (f"📍 <strong>Address:</strong> {r['address']}<br><br>"
                f"We're situated in the heart of Midtown New York. "
                f"Complimentary parking is available on weeknights from 6 PM. "
                f"The restaurant is fully step-free and accessible.")

    if intent == "contact":
        return (f"📞 <strong>Phone:</strong> {r['phone']}<br>"
                f"📧 <strong>Email:</strong> {r['email']}<br>"
                f"🌐 <strong>Website:</strong> {r['website']}<br><br>"
                f"Our staff are available to assist during all opening hours.")

    if intent == "reservation":
        res = r["reservation"]
        return (f"To secure a table:<br><br>"
                f"📞 Give us a call at <strong>{res['phone']}</strong><br>"
                f"🌐 Or reserve online at <strong>{res['online']}</strong><br><br>"
                f"<em>{res['note']}</em>")

    if intent == "vegetarian":
        veg_items = []
        for category, items in r["menu"].items():
            for item in items:
                if item.get("veg"):
                    veg_items.append(f"<li><strong>{item['name']}</strong> ({category}) — {item['price']} · {item['desc']}</li>")
        return (f"🥗 Vegetarian-friendly options on our menu:<br><br>"
                f"<ul>{''.join(veg_items)}</ul>"
                f"<em>A dedicated plant-based menu is also available — just let your server know!</em>")

    if intent == "parking":
        return "🅿️ Complimentary parking is available in our adjacent lot on <strong>weeknights from 6 PM</strong>. Paid street parking is accessible at all other times."

    if intent == "events":
        return (f"🎉 Our <strong>private dining room</strong> comfortably seats up to 18 guests and is ideal for birthdays, corporate dinners, or family celebrations.<br><br>"
                f"To make an enquiry, call us on {r['phone']} or email {r['email']}.")

    if intent == "music":
        return "🎶 We feature <strong>live acoustic music every Friday and Saturday from 8–10 PM</strong>. We strongly recommend booking ahead on those evenings for the best experience!"

    if intent == "features":
        features_html = "".join(f"<li>{f}</li>" for f in r["features"])
        return f"Here's a glimpse of what sets us apart:<br><ul>{features_html}</ul>"

    if intent == "recommend":
        return ("⭐ Some of our most-loved dishes:<br><br>"
                "🍝 <strong>Spaghetti alla Gricia</strong> — a timeless Roman favourite ($21)<br>"
                "🥩 <strong>Costata alla Fiorentina</strong> — our signature showpiece for celebrations ($62/person)<br>"
                "🍮 <strong>Tiramisù Artigianale</strong> — lovingly crafted in-house ($11)<br>"
                "🎵 Join us on a Friday evening and enjoy live acoustic music too!")

    if intent == "menu":
        msg_lower = msg.lower()
        cat_map = {
            "appetizer": "Appetizers",
            "starter":   "Appetizers",
            "pasta":     "Pasta",
            "main":      "Main Courses",
            "dessert":   "Desserts",
            "drink":     "Beverages",
            "beverage":  "Beverages",
        }
        for keyword, full_cat in cat_map.items():
            if keyword in msg_lower:
                items = r["menu"][full_cat]
                items_html = "".join(
                    f"<li><strong>{i['name']}</strong> — {i['price']}<br><small>{i['desc']}</small></li>"
                    for i in items
                )
                return f"<strong>{full_cat}</strong><br><ul>{items_html}</ul>"

        # Full menu
        full_menu = ""
        for category, items in r["menu"].items():
            full_menu += f"<strong>── {category} ──</strong><br><ul>"
            for item in items:
                full_menu += f"<li><strong>{item['name']}</strong> — {item['price']}<br><small>{item['desc']}</small></li>"
            full_menu += "</ul>"
        return f"Here is our complete menu:<br><br>{full_menu}"

    # Fallback
    return (f"I didn't quite catch that. I can assist with our <strong>menu, opening hours, location, table bookings, or contact details</strong>.<br><br>"
            f"Try something like: <em>\"When are you open?\"</em> or <em>\"What's on the menu?\"</em>")


@app.route("/")
def index():
    return render_template("index.html", restaurant=RESTAURANT_INFO)


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_msg = data.get("message", "").strip()
    if not user_msg:
        return jsonify({"reply": "Please enter a message!"})

    intent = identify_intent(user_msg)
    reply  = generate_reply(intent, user_msg)
    return jsonify({"reply": reply})


if __name__ == "__main__":
    app.run(debug=True)
