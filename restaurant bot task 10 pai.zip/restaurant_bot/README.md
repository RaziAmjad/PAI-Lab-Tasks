# Casa di Roma — Restaurant Chatbot

A Flask-powered restaurant information chatbot with a polished frontend interface.

## Setup & Run

### 1. Install Python dependencies
```bash
pip install -r requirements.txt
```

### 2. Start the application
```bash
python app.py
```

### 3. Open in your browser
```
http://127.0.0.1:5000
```

## What the Bot Can Answer
- Opening times
- Full menu with pricing (Appetizers, Pasta, Main Courses, Desserts, Beverages)
- Vegetarian & plant-based options
- Table reservation information
- Address & directions
- Contact details
- Parking availability
- Private events & group bookings
- Live music schedule
- Chef's recommendations

## Project Structure
```
restaurant_bot/
├── app.py               ← Flask backend + chatbot logic
├── requirements.txt     ← Python dependencies
├── README.md
├── templates/
│   └── index.html       ← Main UI template
└── static/
    ├── css/
    │   └── style.css    ← All styles
    └── js/
        └── chat.js      ← Frontend chat logic
```

## Customization
To adapt this chatbot for your own restaurant, update the `RESTAURANT_INFO` dictionary inside `app.py` with your details.
