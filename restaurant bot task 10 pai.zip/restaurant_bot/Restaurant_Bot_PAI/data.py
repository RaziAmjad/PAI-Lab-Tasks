qna_data = [
    {
        "question": "What is a restaurant?",
        "answer": "A restaurant is a business where people go to eat meals that are prepared and served by staff. Restaurants offer a menu of food and drink items in exchange for payment."
    },
    {
        "question": "How do I make a reservation at a restaurant?",
        "answer": "You can make a reservation by calling the restaurant directly, visiting their website, or using apps like OpenTable or Resy. Provide your name, date, time, and number of guests."
    },
    {
        "question": "What is the difference between fine dining and casual dining?",
        "answer": "Fine dining offers a formal atmosphere, high-end food, professional service, and higher prices. Casual dining is more relaxed, affordable, and family-friendly with a broader menu."
    },
    {
        "question": "What should I do if I have a food allergy?",
        "answer": "Always inform your server about your food allergy before ordering. Ask about ingredients and how the food is prepared. Most restaurants can accommodate common allergies like nuts, gluten, or dairy."
    },
    {
        "question": "How much tip should I leave at a restaurant?",
        "answer": "In most countries, a tip of 15% to 20% of the total bill is standard for good service. In the US, 18-20% is common. Tipping is optional in some countries but always appreciated."
    },
    {
        "question": "What is a prix fixe menu?",
        "answer": "A prix fixe menu is a set menu that offers a fixed number of courses at a fixed price. For example, a three-course meal with a starter, main course, and dessert for a single price."
    },
    {
        "question": "What does farm-to-table mean?",
        "answer": "Farm-to-table means the restaurant sources its ingredients directly from local farms. This ensures fresher food, supports local farmers, and reduces the carbon footprint of the meal."
    },
    {
        "question": "Can I request a customized dish at a restaurant?",
        "answer": "Yes, most restaurants allow modifications to dishes. You can ask to remove or add ingredients, change the cooking style, or adjust spice levels. Politely communicate your needs to your server."
    },
    {
        "question": "What is a tasting menu?",
        "answer": "A tasting menu is a series of small dishes chosen by the chef to showcase the restaurant's best or seasonal offerings. It usually includes many courses and is a popular option at fine dining restaurants."
    },
    {
        "question": "What is the difference between a bistro and a brasserie?",
        "answer": "A bistro is a small, cozy restaurant offering simple home-style meals at affordable prices. A brasserie is larger, serves food throughout the day, and typically offers heartier meals with beer and wine."
    },
    {
        "question": "What is a sommelier?",
        "answer": "A sommelier is a trained wine expert who works in a restaurant. They help guests choose wine that pairs well with their food and manage the restaurant's wine list."
    },
    {
        "question": "What does the term al dente mean?",
        "answer": "Al dente is an Italian cooking term meaning pasta or vegetables are cooked until firm to the bite, not soft or mushy. It is considered the ideal texture for well-cooked pasta."
    },
    {
        "question": "What is a table d'hote?",
        "answer": "Table d'hote is a menu that offers a full meal with limited choices at a fixed price. Unlike an a la carte menu where each item is priced separately, table d'hote gives a complete meal for one set price."
    },
    {
        "question": "How do I complain about bad food or service at a restaurant?",
        "answer": "Politely inform your server or ask to speak with the manager. Explain your concern calmly and clearly. Most restaurants will offer to fix the dish or provide a discount. You can also leave an online review."
    },
    {
        "question": "What does BYOB mean at a restaurant?",
        "answer": "BYOB stands for Bring Your Own Bottle. Some restaurants allow guests to bring their own wine or alcohol, often charging a small corkage fee for opening and serving the bottle."
    }
]
