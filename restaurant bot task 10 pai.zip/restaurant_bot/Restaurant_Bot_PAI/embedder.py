from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from data import qna_data

# Load the embedding model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Extract all questions
questions = [item["question"] for item in qna_data]
answers = [item["answer"] for item in qna_data]

# Convert questions to vectors
question_vectors = model.encode(questions)
question_vectors = np.array(question_vectors).astype('float32')

# Build FAISS index
dimension = question_vectors.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(question_vectors)

def get_answer(user_question):
    # Convert user question to vector
    user_vector = model.encode([user_question])
    user_vector = np.array(user_vector).astype('float32')
    
    # Search for closest match
    distances, indices = index.search(user_vector, 1)
    
    best_index = indices[0][0]
    best_distance = distances[0][0]
    
    # If distance is too high, question is not relevant
    if best_distance > 2.0:
        return "Sorry, I don't have information on that topic. Please ask something related to restaurants or dining."
    
    matched_question = questions[best_index]
    matched_answer = answers[best_index]
    
    return {
        "matched_question": matched_question,
        "answer": matched_answer,
        "confidence": round(float(1 / (1 + best_distance)) * 100, 2)
    }
