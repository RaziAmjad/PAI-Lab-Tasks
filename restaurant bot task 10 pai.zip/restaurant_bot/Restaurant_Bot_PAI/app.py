from flask import Flask, render_template, request, jsonify
from embedder import get_answer

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    data = request.get_json()
    user_question = data.get('question', '').strip()
    
    if not user_question:
        return jsonify({"error": "Please enter a question."})
    
    result = get_answer(user_question)
    
    if isinstance(result, str):
        return jsonify({"answer": result, "matched_question": "", "confidence": 0})
    
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
