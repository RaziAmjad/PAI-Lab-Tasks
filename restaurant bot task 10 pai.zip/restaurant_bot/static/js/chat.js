const chatWindow = document.getElementById("chatMessages");
const inputField = document.getElementById("userInput");
const submitBtn  = document.getElementById("sendBtn");

// ── Utility Functions ─────────────────────────────────────────────

function addMessage(content, role) {
  const row = document.createElement("div");
  row.className = `msg-row ${role}`;

  const avatar = document.createElement("div");
  avatar.className = `avatar ${role}`;
  avatar.textContent = role === "bot" ? "🍕" : "👤";

  const bubble = document.createElement("div");
  bubble.className = `bubble ${role}`;
  bubble.innerHTML = content;

  row.appendChild(avatar);
  row.appendChild(bubble);
  chatWindow.appendChild(row);
  scrollDown();
}

function showTypingBubble() {
  const row = document.createElement("div");
  row.className = "msg-row bot";
  row.id = "typingRow";

  const avatar = document.createElement("div");
  avatar.className = "avatar bot";
  avatar.textContent = "🍕";

  const indicator = document.createElement("div");
  indicator.className = "typing-indicator";
  indicator.innerHTML = `<div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div>`;

  row.appendChild(avatar);
  row.appendChild(indicator);
  chatWindow.appendChild(row);
  scrollDown();
}

function removeTypingBubble() {
  const el = document.getElementById("typingRow");
  if (el) el.remove();
}

function scrollDown() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

// ── Message Sending ───────────────────────────────────────────────

async function sendMessage(text) {
  const userText = (text || inputField.value).trim();
  if (!userText) return;

  inputField.value = "";
  addMessage(userText, "user");
  showTypingBubble();
  submitBtn.disabled = true;

  try {
    const response = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: userText })
    });
    const result = await response.json();
    removeTypingBubble();
    addMessage(result.reply, "bot");
  } catch (err) {
    removeTypingBubble();
    addMessage("Apologies, there seems to be a connection issue. Please try again shortly.", "bot");
  } finally {
    submitBtn.disabled = false;
    inputField.focus();
  }
}

// ── Event Listeners ───────────────────────────────────────────────

submitBtn.addEventListener("click", () => sendMessage());

inputField.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

document.querySelectorAll(".quick-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const msg = btn.getAttribute("data-msg");
    sendMessage(msg);
  });
});

// ── Initial Welcome Message ───────────────────────────────────────

window.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    addMessage(
      "Benvenuto! 👋 Welcome to <strong>Casa di Roma</strong>.<br><br>" +
      "I'm your digital host. I'm here to help with our <strong>menu, opening times, location, and table reservations</strong>.<br><br>" +
      "Use the shortcut buttons on the left, or simply type your question below!",
      "bot"
    );
  }, 400);
});
